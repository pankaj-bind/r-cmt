import os
import glob
import pandas as pd

def analyze_gemini_results(csv_filepath):
    model_name = os.path.splitext(os.path.basename(csv_filepath))[0]
    
    try:
        df = pd.read_csv(csv_filepath)
    except FileNotFoundError:
        print(f"ERROR: Could not find {csv_filepath}.")
        return None

    total_problems = len(df)
    if total_problems == 0:
        return None
    
    # FORMAL VERIFICATION VERDICTS
    unsat_count = (df['verdict'] == 'UNSAT').sum()
    sat_count = (df['verdict'] == 'SAT').sum()
    warning_count = (df['verdict'] == 'WARNING').sum()
    
    # Convert to percentages
    unsat_rate = (unsat_count / total_problems) * 100
    sat_rate = (sat_count / total_problems) * 100
    warning_rate = (warning_count / total_problems) * 100
    
    # Calculate Error as the remaining percentage
    error_rate = 100.0 - (unsat_rate + sat_rate + warning_rate)
    
    return {
        "Model": model_name,
        "UNSAT (%)": f"{unsat_rate:.1f}%",
        "SAT (%)": f"{sat_rate:.1f}%",
        "WARNING (%)": f"{warning_rate:.1f}%",
        "Error (%)": f"{error_rate:.1f}%"
    }

def save_and_print_markdown_table(results, filename="comparison_table.md"):
    if not results:
        print("No data to display.")
        return
        
    headers = list(results[0].keys())
    
    # Calculate column widths for nice formatting
    col_widths = {h: len(h) for h in headers}
    for row in results:
        for h in headers:
            col_widths[h] = max(col_widths[h], len(str(row[h])))
            
    header_row = "| " + " | ".join(h.ljust(col_widths[h]) for h in headers) + " |"
    separator_row = "|" + "|".join("-" * (col_widths[h] + 2) for h in headers) + "|"
    
    lines = [header_row, separator_row]
    for row in results:
        lines.append("| " + " | ".join(str(row[h]).ljust(col_widths[h]) for h in headers) + " |")
        
    markdown_output = "\n".join(lines)
    
    # Print to console
    print("\n" + markdown_output + "\n")
    
    # Save to Markdown file
    with open(filename, "w", encoding="utf-8") as f:
        f.write(markdown_output + "\n")
    print(f"✅ Table successfully saved to {os.path.abspath(filename)}")

if __name__ == "__main__":
    csv_files = glob.glob("*.csv")
    if not csv_files:
        print("No CSV files found in the current directory.")
    else:
        print(f"Found {len(csv_files)} CSV files.")
        choice = input("Enter the number of the CSV file to analyze (type 'all' or press Enter for all): ").strip()
        
        results_list = []
        
        if choice.lower() == "all" or choice == "":
            for file in csv_files:
                res = analyze_gemini_results(file)
                if res:
                    results_list.append(res)
        else:
            try:
                choice_idx = int(choice) - 1
                if 0 <= choice_idx < len(csv_files):
                    res = analyze_gemini_results(csv_files[choice_idx])
                    if res:
                        results_list.append(res)
                else:
                    print("Invalid choice. Exiting.")
            except ValueError:
                print("Invalid input. Exiting.")
                
        # Generate and save the final table
        save_and_print_markdown_table(results_list)